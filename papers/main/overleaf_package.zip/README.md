# Main Paper Draft

Working title:

> Selective Trust for Medical Vision-Language Models under Distribution Shift

Current draft sections:

```text
sections/00_abstract.md
sections/01_introduction.md
sections/02_related_work.md
sections/03_methods.md
sections/04_results.md
sections/05_discussion.md
sections/06_conclusion.md
```

Key assets:

- `figures/stage2/fig01_framework.*`
- `figures/stage2/fig09_selective_trust_method.*`
- `figures/stage2/fig10_clinical_workflow.*`
- `figures/stage2/fig02_image_reliance_main.*`
- `tables/stage2/table01_image_reliance.*`
- `tables/stage2/table08_main_performance_calibration.*`

Status: Methods + Results first draft based on real Stage 2 pilot results.


## LaTeX draft

```text
main.tex
refs.bib
Makefile
sections/*.tex
```

Compile:

```bash
cd papers/main
make
```

A TeX distribution (TeX Live/MiKTeX) is required.
